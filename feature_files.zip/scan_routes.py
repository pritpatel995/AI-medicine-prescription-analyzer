import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile, status

from app.auth import get_current_user
from app.llm_parser import structure_prescription
from app.ocr_engine import extract_text
from app.schemas import ScanResponse

router = APIRouter(prefix="/api/scan", tags=["scan"])
logger = logging.getLogger("rx_analyzer.scan")

MAX_UPLOAD_BYTES = 12 * 1024 * 1024  # 12 MB
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/heic", "image/webp"}


@router.post("", response_model=ScanResponse)
async def scan_prescription(
    file: UploadFile,
    current_user: dict = Depends(get_current_user),
):
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported content type: {file.content_type}",
        )

    image_bytes = await file.read()
    if len(image_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="Image exceeds 12MB limit",
        )

    try:
        raw_text = extract_text(image_bytes)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception:
        logger.exception("OCR pipeline failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="OCR processing failed",
        )

    if not raw_text.strip():
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No readable text detected in image. Try retaking the photo with better lighting.",
        )

    extracted = await structure_prescription(raw_text)

    return ScanResponse(
        raw_ocr_text=raw_text,
        extracted=extracted,
        source_image_id=str(uuid.uuid4()),
    )
