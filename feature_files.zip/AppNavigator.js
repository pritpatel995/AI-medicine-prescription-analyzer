
import React from "react";
import { ActivityIndicator, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import ReminderSettingsScreen from "../screens/ReminderSettingsScreen";
import {
  Home,
  Pill,
  UserRound,
} from "lucide-react-native";

import { useAuth } from "../context/AuthContext";
import AuthScreen from "../screens/AuthScreen";
import DashboardScreen from "../screens/DashboardScreen";
import ScanScreen from "../screens/ScanScreen";
import ManualMedicineScreen from "../screens/ManualMedicineScreen";
import ReviewScreen from "../screens/ReviewScreen";
import ProfileScreen from "../screens/ProfileScreen";
import PrescriptionsScreen from "../screens/PrescriptionsScreen";
import { colors } from "../theme/theme";

const RootStack = createNativeStackNavigator();
const AppStack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarStyle: {
          height: 68,
          paddingTop: 8,
          paddingBottom: 8,
          backgroundColor: colors.card,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          elevation: 12,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "700",
        },
        tabBarIcon: ({ color, size, focused }) => {
          const iconSize = focused ? 23 : 21;

          if (route.name === "Home") {
            return <Home size={iconSize} color={color} />;
          }

          if (route.name === "Prescriptions") {
            return <Pill size={iconSize} color={color} />;
          }

          return <UserRound size={iconSize} color={color} />;
        },
      })}
    >
      <Tab.Screen
        name="Home"
        component={DashboardScreen}
        options={{ tabBarLabel: "Home" }}
      />

      <Tab.Screen
        name="Prescriptions"
        component={PrescriptionsScreen}
        options={{
          tabBarLabel: "Prescriptions",
          headerShown: true,
          title: "Prescription History",
          headerStyle: { backgroundColor: colors.bg },
          headerShadowVisible: false,
        }}
      />

      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarLabel: "Profile",
          headerShown: true,
          title: "My Profile",
          headerStyle: { backgroundColor: colors.bg },
          headerShadowVisible: false,
        }}
      />
    </Tab.Navigator>
  );
}

function AppFlow() {
  return (
    <AppStack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <AppStack.Screen name="MainTabs" component={MainTabs} />
      <AppStack.Screen
  name="ReminderSettings"
  component={ReminderSettingsScreen}
  options={{
    headerShown: true,
    title: "Reminder Settings",
    headerStyle: { backgroundColor: colors.bg },
    headerTintColor: colors.text,
    headerShadowVisible: false,
    animation: "slide_from_right",
  }}
/>

      <AppStack.Screen name="Scan" component={ScanScreen} />

      <AppStack.Screen

      
        name="ManualMedicine"
        component={ManualMedicineScreen}
        options={{
          headerShown: false,
          animation: "slide_from_right",
        }}
      />

      <AppStack.Screen
        name="Review"
        component={ReviewScreen}
        options={{
          headerShown: true,
          title: "",
          headerStyle: { backgroundColor: colors.bg },
          headerShadowVisible: false,
        }}
      />
    </AppStack.Navigator>
  );
}

function AuthFlow() {
  return (
    <RootStack.Navigator
      screenOptions={{ headerShown: false, animation: "fade" }}
    >
      <RootStack.Screen name="Auth" component={AuthScreen} />
    </RootStack.Navigator>
  );
}

function SplashLoader() {
  return (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.bg,
      }}
    >
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}

export default function AppNavigator() {
  const { isAuthenticated, isBootstrapping } = useAuth();

  if (isBootstrapping) {
    return <SplashLoader />;
  }

  return (
    <NavigationContainer>
      {isAuthenticated ? <AppFlow /> : <AuthFlow />}
    </NavigationContainer>
  );
}

